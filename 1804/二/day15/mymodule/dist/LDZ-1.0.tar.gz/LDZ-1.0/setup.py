from distutils.core import setup
setup(name = "LDZ",version = "1.0",description = "LDZ's module",author = 'LDZ',py_modules = ['suba.j'])
