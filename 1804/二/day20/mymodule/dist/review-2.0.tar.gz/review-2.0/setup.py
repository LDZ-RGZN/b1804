from distutils.core import setup
setup(name = 'review',version = '2.0',description = 'ldz.s module',author = 'LHDXZL',py_modules = ['class.Car','class.instance','class.plant','class.polymorphic','file.gushi','file.posi','file.test','file.title','rename.os'])

