import os
os.rename ('jui.py','xin.py')
#删除
os.remove ('xin.py')
