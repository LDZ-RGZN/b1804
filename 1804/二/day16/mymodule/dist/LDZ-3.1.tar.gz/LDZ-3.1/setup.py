from distutils.core import setup
setup(name = "LDZ",version = "3.1",description = "LDZ's module",author = "LHDZXL",py_modules = ['suba.BugCar','suba.FullCar','suba.lx','suba.oneFullCar'])
