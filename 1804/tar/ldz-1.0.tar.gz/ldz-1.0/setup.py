from distutils.core import setup
setup(name = 'ldz',version = '1.0',description = "ldz's 计算器",author = 'ldz',py_计算器s = ['suda.j'])
