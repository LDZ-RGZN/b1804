#定义一个home类
class Home:
    def __init__(self,area):
        self.area = area #房间剩余的可用面积
        self.light = open #灯默认是亮的
        self.contains = []
    def __str__(self):
        msg = '当前房间可用面积为' + str(self.area)
        if len(self.contains) > 0:
            msg = msg + '容纳的物品有:'
            for temp in self.contains:
                msg = msg + temp.getName() + ','   #不明白为什么temp可以调用Bed方法
            msg = msg.strip(',')
        return msg
    #容纳物品
    def accommodateItem(self,item):
        #如果可用面积大于物品的占用面积
        needArea = item.getUsedArea()
        if self.area > needArea:
            self.contains.append(item)
            self.area -= needArea
            print ('ok')
        else:
            print ("err:房间可用面积为:%d,但是当前要存放的物品需要的面积为%d"%(self.area, needArea))
#定义bed类
class Bed(object):
    def __init__(self,area,name = '床'):
        self.name = name
        self.area = area
    def __str__(self):
        msg = '床的面积为:' + str(self.area)
        return msg
    #获取床的占用面积
    def getUsedArea(self):
        return self.area
    def getName(self):
        return self.name

newHome = Home(100)#100
print (newHome)

newBed = Bed(20)
print (newBed)

newHome.accommodateItem(newBed)
print (newHome)

newBed2 = Bed(90,'席梦思')
print (newBed2)

newHome.accommodateItem(newBed2)
print (newHome)


