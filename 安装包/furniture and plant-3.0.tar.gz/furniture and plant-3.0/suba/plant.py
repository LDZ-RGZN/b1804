#鞋,基类(抽象产品)
class Shoe:
    def walk(self):
        pass
#皮鞋具体产品
class LeatherShoe(Shoe):
    def walk(self):
        print ('优雅的皮鞋')
#球鞋具体产品
class SoccerShoe(Shoe):
    def walk(self):
        print ('愤怒的球鞋')
#鞋厂,基类 抽象工厂
class ShoeFactory(object):
    def make_shone(self):
        pass
#皮鞋车间 具体工厂
class LeatherShoeFactory(ShoeFactory):
    def make_shoe(self):
        return LeatherShoe()
#球鞋车间 具体工厂
class SoccerShoeFactory(ShoeFactory):
    def make_shoe(self):
        return SoccerShoe()
#安利打电话要鞋
def anli_call():
    factory = LeatherShoeFactory()
    for i in range(3):
        shoe = factory.make_shoe()
        shoe.walk()
#恒大打电话要鞋
def hengda_call():
    factory = SoccerShoeFactory()
    for i in range(3):
        shoe = factory.make_shoe()
        shoe.walk()
if __name__ == '__main__':
    anli_call()
    hengda_call()


