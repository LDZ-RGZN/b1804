from distutils.core import setup
setup(name = 'furniture and plant',version = '3.0',description = 'ldz.plant',author = 'LHDXZL',py_modules = ['suba.furniture','suba.plant'])
