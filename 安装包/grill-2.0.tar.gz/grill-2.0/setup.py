from distutils.core import setup
setup(name = 'grill',version = '2.0',description = 'LHDXZL module',author = 'LDZ',py_modules = ['suba.Car','suba.SweetPotato'])
