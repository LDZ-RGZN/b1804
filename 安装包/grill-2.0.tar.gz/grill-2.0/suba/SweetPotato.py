#我们用工厂模式做一个烧烤店
#烧烤店  烧烤炉  食物
#定义一个基本的店铺类
class Shop(object):
    __instance = None
    def createGrill(self):
        pass
    def Finished(self,name):
        self.grill = self.createGrill(name)
        print (self.grill.jieguo())
    def __new__(cls,*k):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls)
        return cls.__instance
#食品店__________________________________________
class GrillShop(Shop):
    def createGrill(self,name):
        self.grill = food(name)
        return self.grill
#食物_____________________________________________
class food(object):
    def __init__(self,name):
        self.name = name
    def jieguo(self):
        return '香喷喷的烤' + self.name + '已经为您做好,请您慢慢享用(O_O)'
#食品函数___________________________
def skd(name):
    sk = GrillShop()
    sk.Finished(dic[name])
#_________________________________
print ('   欢迎光临米奇烧烤店')
print ('    *****菜单*****')
print ('   1.土豆     2.茄子')
print ('   3.地瓜     4.黄瓜')
dic = {'1':'土豆','2':'茄子','3':'地瓜','4':'黄瓜'}
while True:
    name = input ('请问您要吃点什么')
    skd(name)
    print ('1.继续     2.退出')
    wan = int (input ('是否继续'))
    if wan == 2:
        break
























